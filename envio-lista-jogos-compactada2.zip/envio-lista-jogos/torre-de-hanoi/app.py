from flask import Flask, render_template, redirect, url_for, request

app = Flask(__name__)

# CLASSES

class Disco:
    def __init__(self, nome, cor, tamanho):
        self.nome = nome
        self.cor = cor
        self.tamanho = tamanho

class Poste:
    def __init__(self, nome):
        self.nome = nome
        self.discos = []

    def adicionar_disco(self, disco):
        self.discos.append(disco)

    def mover_disco(self, poste_destino):
        if not self.discos:
            return False
        
        disco = self.discos[-1]
        if poste_destino.discos and disco.tamanho > poste_destino.discos[-1].tamanho:
            return False
            
        self.discos.pop()
        poste_destino.adicionar_disco(disco)
        return True

# ESTADO DO JOGO 

discos = [
    Disco("n5", "red", 5),
    Disco("n4", "orange", 4),
    Disco("n3", "yellow", 3),
    Disco("n2", "green", 2),
    Disco("n1", "blue", 1)
]

postes = [Poste("A"), Poste("B"), Poste("C")]
for disco in discos:
    postes[0].adicionar_disco(disco)

mapa_postes = {poste.nome: poste for poste in postes}
movimentos = 0

@app.route("/")
def index():
    return render_template(
        "index.html", postes=postes, movimentos=movimentos
    )

@app.route("/mover", methods=["POST"])
def mover():
    global movimentos
    origem = request.form.get("origem")
    destino = request.form.get("destino")

    if origem in mapa_postes and destino in mapa_postes:
        if mapa_postes[origem].mover_disco(mapa_postes[destino]):
            movimentos += 1

    return redirect(url_for("index"))

@app.route("/resetar")
def resetar():
    global postes, mapa_postes, movimentos
    postes = [Poste("A"), Poste("B"), Poste("C")]
    for disco in discos:
        postes[0].adicionar_disco(disco)
    mapa_postes = {poste.nome: poste for poste in postes}
    movimentos = 0
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
