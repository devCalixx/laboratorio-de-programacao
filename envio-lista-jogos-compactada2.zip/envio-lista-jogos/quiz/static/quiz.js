let pontuacao = 0;
let perguntaAtual = 0;

document.getElementById('start-btn').addEventListener('click', () => {
    document.getElementById('ready-modal').style.display = 'none';
    carregarPergunta();
});

function carregarPergunta() {
    fetch(`/pergunta/${perguntaAtual}`)
        .then(response => response.json())
        .then(data => {
            if (data.fim) {
                alert(`🎉 Fim do quiz! Sua pontuação final foi ${pontuacao}.`);
                return;
            }
            document.getElementById('question-text').textContent = data.texto;
            const choices = document.querySelector('.choices');
            choices.innerHTML = '';
            data.alternativas.forEach(alternativa => {
                const btn = document.createElement('button');
                btn.className = 'choice-button';
                btn.textContent = alternativa;
                btn.onclick = () => responder(btn);
                choices.appendChild(btn);
            });
            document.getElementById('pergunta-atual').textContent = perguntaAtual + 1;
        });
}

function responder(button) {
    const resposta = button.textContent;
    fetch('/verificar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ num: perguntaAtual, resposta })
    })
    .then(response => response.json())
    .then(data => {
        if (data.acertou) {
            pontuacao++;
            alert('✅ Certa resposta!');
        } else {
            alert(`❌ Errado! Resposta correta: ${data.correta}`);
        }
        document.getElementById('pontuacao').textContent = pontuacao;
        perguntaAtual++;
        carregarPergunta();
    });
}
